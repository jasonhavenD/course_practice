/*
    build :gcc webserv.c socklib.c -o webserv -w
    run :./webserv 8080
*/
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <string.h>
#include <sys/utsname.h>
#include <fcntl.h>
#include <unistd.h>
#include <time.h>

main(int ac,char*av[])
{
    //socket描述符和accept描述符
    int sock,fd;
    FILE *fpin;
    //保存请求
    char request[BUFSIZ];
    if(ac==1)
    {
        fprintf(stderr,"usage:ws portnum\n");
        exit(1);
    }
    sock =make_server_socket(atoi(av[1]));//atoi方法将字符串变成整型
    if(sock==-1) exit(2);

    //创建日志文件
    createLog();

    while(1)
    {
        //该函数会阻塞等待客户端请求到达
        fd =accept(sock,NULL,NULL);
        //只读方式接收请求(文件流)
        fpin=fdopen(fd,"r");
        //得到请求
        fgets(request,BUFSIZ,fpin);
        //打印到控制台请求记录
        printf("got a call :request = %s",request);
        //记录日志文件
        writeLog(request);
        read_til_crnl(fpin);
        //处理请求
        process_rq(request,fd);
        //结束本次请求
        fclose(fpin);
    }
}


//创建日志文件
createLog()
{
    if((access("./log",F_OK))!=-1)
    {
        //日志文件存在则清空内容
        int ret = open("./log", O_WRONLY | O_TRUNC);
        if(ret == -1)
        {
            printf("打开日志文件失败!\n");
            return;
        }
        close(ret);
    }
    else
    {
        //日志文件不存在则创建
        system("touch ./log");
        system("chmod 744 ./log");
    }
}


//记录日志文件
writeLog(char *request)
{
    char temp[225]="got a call : request = ";
    strcat(temp,request);
    int logfd;
    //打开文件
    if((logfd=open("./log",O_RDWR|O_APPEND,0644))<0)
    {
        perror("打开日志文件出错！");
        exit(1);
    }
    //获取当前时间
    int z;
    struct tm *t;
    time_t tt;
    time(&tt);
    t = localtime(&tt);
    char time[18];
    sprintf(time,"%4d年%02d月%02d日 %02d:%02d:%02d\r\n", t->tm_year + 1900, t->tm_mon + 1, t->tm_mday, t->tm_hour, t->tm_min, t->tm_sec);
    z=write(logfd,time,150);
    if(z<0)
    {
        perror("写入日志文件出错！");
        exit(1);
    }
    //关闭文件
    if(close(logfd))
    {
        perror("关闭日志文件出错！");
        exit(1);
    }

}


//读取完整的请求
read_til_crnl(FILE*fp)
{
    char buf[BUFSIZ];
    while(fgets(buf,BUFSIZ,fp)!=NULL&&strcmp(buf,"\r\n")!=0);
}


//处理请求
process_rq(char *rq, int fd)
{
    char cmd[BUFSIZ],arg[BUFSIZ];
    //创建子进程，如果不是子进程则结束
    if (fork()!=0)
        return;
    strcpy(arg,"./");
    if (sscanf(rq,"%s%s",cmd,arg+2)!=2)
        return;
    if(strcmp(cmd,"GET")!=0)//只能处理静态网页get方式
        cannot_do(fd);
    else if (not_exist(arg))//请求出错
        do_404(arg,fd);
    else if (isadir(arg))//判断是否为目录
        do_ls(arg,fd);
    else if (ends_in_cgi(arg))//是否为cgi程序
        do_exec(arg,fd);
    else if (ends_in_sh(arg))//是否为sh程序
        do_exec_sh(arg,fd);
    else
        do_cat(arg,fd);
}


//获取头部信息
header(FILE *fp,char*content_type)
{
    fprintf(fp,"HTTP/1.0 200 OK\r\n");
    if(content_type)
        fprintf(fp,"Content-type: %s\r\n",content_type);
}

//请求501错误
cannot_do(int fd)
{
    FILE *fp =fdopen(fd,"w");

	fprintf(fp,"HTTP/1.0 501 Not Implemented\r\n");
    fprintf(fp,"Content-type:text/plain\r\n");
    fprintf(fp,"\r\n");
    fprintf(fp,"Sorry,HTTP 501!\n\n无法处理请求!");
    fclose(fp);

}


//请求出错404
do_404(char *item,int fd)
{
    FILE *fp=fdopen(fd,"w");

    fprintf(fp,"HTTP/1.0 404 Not Found\r\n");
    fprintf(fp,"Content-type:text/plain\r\n");
    fprintf(fp,"\r\n");
    fprintf(fp,"Sorry,HTTP 404!\n\nThe item you requested: %s \r\nis not found\r\n",item);
    fclose(fp);
}


//判断是否为目录
isadir(char*f)
{
    struct stat info;
    return (stat(f,&info)!=-1&&S_ISDIR(info.st_mode));

}


//不存在
not_exist(char *f)
{
    struct stat info;
    return (stat(f,&info)==-1);
}


//显示目录下内容
do_ls(char*dir,int fd)
{
    FILE *fp;

    fp = fdopen(fd,"w");
    header(fp,"text/plain;charset=UTF-8");
    fprintf(fp,"\r\n");
    fflush(fp);

    dup2(fd,1);
    dup2(fd,2);
    close(fd);
    execlp("ls","ls","-l",dir,NULL);
    perror(dir);
    exit(1);
}


//返回文件类型
char* file_type(char *f)//return 'extension' of file
{
    char *cp;
    if((cp=strrchr(f,'.'))!=NULL)
        return cp+1;
    return " ";
}

//cgi类型文件
ends_in_cgi(char *f)
{
    return(strcmp(file_type(f),"cgi")==0);
}



//执行shell程序
ends_in_sh(char *f)
{
    return(strcmp(file_type(f),"sh")==0);
}

do_exec_sh(char *prog,int fd)
{
    system(prog);
}//shell


//执行可执行程序cgi
do_exec(char *prog,int fd)
{
    FILE *fp;
    fp =fdopen(fd,"w");
    header(fp,NULL);
    fflush(fp);
    
    dup2(fd,1);
    dup2(fd,2);
    close(fd);
    execl(prog,prog,NULL);
    perror(prog);
    
}


//显示当前目录下全部文件或目录
do_cat(char*f,int fd)
{
    char *extension=file_type(f);
    char *content="text/html";
    FILE *fpsock,*fpfile;
    int c;

    if(strcmp(extension,"html")==0)
        content="text/html";
    else if (strcmp(extension,"gif")==0)
        content="image/gif";
    else if(strcmp(extension,"jpg")==0)
        content="image/jpeg";
    else if(strcmp(extension,"jpeg")==0)
        content="image/jpeg";

    fpsock = fdopen(fd,"w");
    fpfile = fopen(f,"r");
    if(fpsock!=NULL&&fpfile!=NULL)
    {
        header(fpsock,content);
        fprintf(fpsock,"\r\n");
        while((c=getc(fpfile))!=EOF)
            putc(c,fpsock);
        fclose(fpfile);
        fclose(fpsock);
    }
    exit(0);
}
